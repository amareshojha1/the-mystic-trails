import React, { useState, useMemo, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation, Link } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import ScentFinder from './components/ScentFinder';
import CartDrawer from './components/CartDrawer';
import ProductPage from './pages/ProductPage';
import { PRODUCTS, CATEGORIES } from './constants';
import { Product, CartItem } from './types';
import { ShoppingBag, RefreshCw, Droplets, Leaf, Sparkles, Heart, CheckCircle2 } from 'lucide-react';

const ScrollToTop = () => {
  const { pathname, hash } = useLocation();
  useEffect(() => {
    if (hash) {
      const el = document.getElementById(hash.replace('#', ''));
      if (el) {
        el.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      window.scrollTo(0, 0);
    }
  }, [pathname, hash]);
  return null;
};

const HomePage: React.FC<{ 
  selectedCategory: string, 
  setSelectedCategory: (c: string) => void, 
  filteredProducts: Product[],
  addToCart: (p: Product) => void
}> = ({ selectedCategory, setSelectedCategory, filteredProducts, addToCart }) => (
  <main>
    <Hero />
    
    {/* Impact Section */}
    <section id="impact" className="py-32 bg-mystic-cream relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div>
            <span className="text-mystic-green font-bold uppercase tracking-[0.3em] text-[10px] mb-6 block">The Problem</span>
            <h2 className="text-4xl md:text-5xl font-serif text-mystic-dark italic mb-8 leading-tight">
              The Unseen Journey of a Million Prayers
            </h2>
            <div className="space-y-6 text-gray-600 leading-relaxed text-lg">
              <p>
                Karnataka is home to over <span className="text-mystic-green font-bold">61,000 temples</span> where every morning begins with lakhs of devotees offering fresh flowers.
              </p>
              <p className="bg-mystic-pink/10 border-l-4 border-mystic-pink p-6 italic text-mystic-dark font-medium">
                "But once the prayers are over, these flowers are swept into garbage bags, rotting in landfills and contaminating our groundwater."
              </p>
              <p>
                The Mystic Trails gives these blessings a new beginning by rescuing them from the waste stream. Every marigold and rose you smell in our sticks was once a part of someone's sacred offering.
              </p>
            </div>
          </div>
          <div className="relative group">
            <div className="absolute -inset-4 bg-mystic-green/5 rounded-[40px] transform rotate-3 group-hover:rotate-0 transition-transform duration-700"></div>
            <img 
              src="https://images.unsplash.com/photo-1528666373302-3c3f25c7e114?auto=format&fit=crop&q=80&w=1200" 
              alt="Temple Marigold Rescue" 
              className="relative z-10 rounded-[32px] shadow-2xl grayscale group-hover:grayscale-0 transition-all duration-1000 w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>

    {/* Process Section */}
    <section className="py-24 bg-white border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-20">
          <h2 className="text-3xl font-serif italic text-mystic-dark">From Petal to Product</h2>
          <div className="w-20 h-[2px] bg-mystic-green/20 mx-auto mt-6"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {[
            { icon: <RefreshCw />, title: "Collect", desc: "Temple flowers rescued from 20+ temples daily." },
            { icon: <Droplets />, title: "Sort & Dry", desc: "Innovative solar drying techniques." },
            { icon: <Leaf />, title: "Grind", desc: "Pure floral powder mixed with natural resins." },
            { icon: <Sparkles />, title: "Create", desc: "Soulful, handcrafted lifestyle products." }
          ].map((step, i) => (
            <div key={i} className="text-center flex flex-col items-center group">
              <div className="w-16 h-16 bg-mystic-green/5 rounded-full flex items-center justify-center text-mystic-green mb-6 group-hover:bg-mystic-green group-hover:text-white transition-all duration-500">
                {step.icon}
              </div>
              <h3 className="text-sm uppercase tracking-widest font-bold mb-3">{step.title}</h3>
              <p className="text-gray-500 text-sm italic leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* Shop Section */}
    <section id="shop" className="py-32 bg-mystic-cream">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20">
          <div className="max-w-xl">
            <span className="text-mystic-green font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">Handcrafted with Purpose</span>
            <h2 className="text-4xl font-serif italic text-mystic-dark">The Collections</h2>
          </div>
          <div className="flex flex-wrap gap-4 mt-8 md:mt-0 overflow-x-auto pb-4 scrollbar-hide">
            {CATEGORIES.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-8 py-3 rounded-full border text-[10px] uppercase tracking-widest font-bold transition-all whitespace-nowrap
                  ${selectedCategory === cat 
                    ? 'bg-mystic-green border-mystic-green text-white shadow-xl translate-y-[-2px]' 
                    : 'bg-white border-mystic-green/10 text-mystic-dark hover:border-mystic-green'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-16">
          {filteredProducts.map(product => (
            <div key={product.id} className="group" id={`product-${product.id}`}>
              <Link to={`/product/${product.id}`} className="block">
                <div className="relative aspect-[4/5] overflow-hidden bg-gray-100 rounded-2xl mb-6 shadow-md group-hover:shadow-xl transition-all">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-all duration-700" />
                </div>
              </Link>
              <div className="text-left px-2">
                <div className="flex justify-between items-start mb-2">
                  <Link to={`/product/${product.id}`} className="text-lg font-serif italic text-mystic-dark hover:text-mystic-green transition-colors">{product.name}</Link>
                  <p className="font-bold text-mystic-green">₹{product.price}</p>
                </div>
                <p className="text-gray-400 text-xs italic mb-4 line-clamp-2">{product.description}</p>
                <button 
                  onClick={() => addToCart(product)}
                  className="w-full bg-mystic-green/5 hover:bg-mystic-green text-mystic-green hover:text-white py-3 rounded-xl text-[9px] uppercase tracking-widest font-bold transition-all flex items-center justify-center space-x-2"
                >
                  <ShoppingBag size={12} />
                  <span>Quick Add</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
    <ScentFinder />
  </main>
);

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [isOrderSuccess, setIsOrderSuccess] = useState(false);

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                           p.description.toLowerCase().includes(searchTerm.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [selectedCategory, searchTerm]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  return (
    <Router>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col selection:bg-mystic-pink selection:text-white">
        <Header 
          cartCount={cart.reduce((s, i) => s + i.quantity, 0)} 
          toggleCart={() => setIsCartOpen(true)}
          onSearch={setSearchTerm}
        />
        
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={
              <HomePage 
                selectedCategory={selectedCategory} 
                setSelectedCategory={setSelectedCategory} 
                filteredProducts={filteredProducts}
                addToCart={addToCart}
              />
            } />
            <Route path="/product/:id" element={<ProductPage onAddToCart={addToCart} />} />
            <Route path="*" element={
              <HomePage 
                selectedCategory={selectedCategory} 
                setSelectedCategory={setSelectedCategory} 
                filteredProducts={filteredProducts}
                addToCart={addToCart}
              />
            } />
          </Routes>
        </div>

        <footer className="bg-white text-gray-400 py-24 border-t border-gray-100">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-16">
            <div className="md:col-span-1">
              <Link to="/" className="flex items-center space-x-2 mb-4">
                <div className="w-6 h-6 bg-mystic-green rounded-full flex items-center justify-center">
                  <Heart className="text-white fill-current" size={10} />
                </div>
                <h1 className="text-lg font-bold tracking-tight text-mystic-dark">
                  The <span className="font-serif italic text-mystic-green">Mystic</span> Trails
                </h1>
              </Link>
              <p className="text-xs italic mb-8">Where flowers find a second life as sacred blessings for your home.</p>
            </div>
            <div>
              <h4 className="text-mystic-dark uppercase tracking-widest text-[10px] font-bold mb-8">Shop</h4>
              <ul className="space-y-4 text-xs italic">
                <li><Link to="/#shop">Collection</Link></li>
                <li><Link to="/#scent-finder">AI Finder</Link></li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-4 mt-24 pt-8 border-t border-gray-50 text-[9px] uppercase tracking-[0.3em] font-bold text-center">
            <p>© 2025 The Mystic Trails. Spiritual Regenerative Brand.</p>
          </div>
        </footer>

        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)}
          items={cart}
          onUpdateQty={(id, delta) => setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item))}
          onRemove={(id) => setCart(prev => prev.filter(item => item.id !== id))}
          onCheckout={() => { setIsCartOpen(false); setIsOrderSuccess(true); setCart([]); }}
        />

        {isOrderSuccess && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-mystic-dark/80 backdrop-blur-md" onClick={() => setIsOrderSuccess(false)}></div>
            <div className="relative bg-white max-w-lg w-full rounded-[40px] p-12 text-center shadow-2xl">
              <div className="w-24 h-24 bg-mystic-green/10 rounded-full flex items-center justify-center mx-auto mb-8">
                <CheckCircle2 size={48} className="text-mystic-green" />
              </div>
              <h2 className="text-3xl font-serif italic mb-4">Blessings received</h2>
              <p className="text-gray-500 italic mb-8">Your order of rescued flowers is being prepared with care.</p>
              <button onClick={() => setIsOrderSuccess(false)} className="bg-mystic-green text-white px-10 py-4 rounded-full text-[10px] uppercase font-bold">Continue Exploring</button>
            </div>
          </div>
        )}
      </div>
    </Router>
  );
};

export default App;