import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { Star, ShieldCheck, Truck, RefreshCw, ChevronLeft, ShoppingBag } from 'lucide-react';
import { Product } from '../types';

interface ProductPageProps {
  onAddToCart: (p: Product) => void;
}

const ProductPage: React.FC<ProductPageProps> = ({ onAddToCart }) => {
  const { id } = useParams();
  const product = PRODUCTS.find(p => p.id === id);

  if (!product) return <div className="py-40 text-center font-serif text-2xl italic">Fragrance not found...</div>;

  return (
    <div className="bg-mystic-cream min-h-screen">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <Link to="/" className="inline-flex items-center space-x-2 text-gray-400 hover:text-mystic-green transition-colors text-[10px] uppercase tracking-widest font-bold mb-12">
          <ChevronLeft size={16} />
          <span>Back to Collection</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Gallery */}
          <div className="space-y-4">
            <div className="aspect-[4/5] rounded-[40px] overflow-hidden bg-white shadow-2xl">
              <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square rounded-2xl overflow-hidden bg-white border border-mystic-green/5 cursor-pointer hover:border-mystic-green transition-all">
                  <img src={product.image} className="w-full h-full object-cover opacity-50 hover:opacity-100 transition-opacity" />
                </div>
              ))}
            </div>
          </div>

          {/* Details */}
          <div className="sticky top-32">
            <span className="text-mystic-pink font-bold uppercase tracking-[0.3em] text-[10px] mb-4 block">{product.category}</span>
            <h1 className="text-5xl font-serif italic text-mystic-dark mb-6">{product.name}</h1>
            
            <div className="flex items-center space-x-4 mb-8">
              <div className="flex items-center space-x-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={14} className={i < Math.floor(product.rating) ? "fill-mystic-green text-mystic-green" : "text-gray-200"} />
                ))}
              </div>
              <span className="text-sm text-gray-400 font-medium">{product.rating} (120+ Reviews)</span>
            </div>

            <p className="text-3xl font-serif text-mystic-green mb-8">₹{product.price}</p>
            
            <p className="text-gray-600 text-lg leading-relaxed italic mb-12">
              {product.description} This scent is part of our regenerative cycle, where every petal is rescued and treated with prayerful intent.
            </p>

            <div className="space-y-6 mb-12">
              <div className="flex items-center space-x-4 text-sm text-gray-500 italic">
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-mystic-green shadow-sm">
                  <ShieldCheck size={18} />
                </div>
                <span>100% Charcoal Free & Toxin Free</span>
              </div>
              <div className="flex items-center space-x-4 text-sm text-gray-500 italic">
                <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-mystic-green shadow-sm">
                  <Truck size={18} />
                </div>
                <span>Sustainable Shipping across India</span>
              </div>
            </div>

            <button 
              onClick={() => onAddToCart(product)}
              className="w-full bg-mystic-green hover:bg-mystic-green/90 text-white py-6 rounded-2xl uppercase tracking-[0.3em] font-bold transition-all shadow-2xl flex items-center justify-center space-x-4 group"
            >
              <ShoppingBag size={18} />
              <span>Add to Satchel</span>
            </button>

            {/* Scent Profile */}
            <div className="mt-16 pt-16 border-t border-mystic-green/10">
              <h3 className="text-[10px] uppercase tracking-[0.4em] font-bold text-mystic-dark mb-8">The Scent Profile</h3>
              <div className="grid grid-cols-3 gap-8">
                <div>
                  <p className="text-[9px] uppercase tracking-widest text-gray-400 mb-2">Top Notes</p>
                  <p className="font-serif italic text-mystic-dark">Fresh Petals</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-widest text-gray-400 mb-2">Heart Notes</p>
                  <p className="font-serif italic text-mystic-dark">Sacred Resin</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-widest text-gray-400 mb-2">Base Notes</p>
                  <p className="font-serif italic text-mystic-dark">Earth & Sandal</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;